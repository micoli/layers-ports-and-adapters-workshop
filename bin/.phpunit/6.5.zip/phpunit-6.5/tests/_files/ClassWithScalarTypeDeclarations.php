<?php
class ClassWithScalarTypeDeclarations
{
    public function foo(string $string, int $int)
    {
    }
}
