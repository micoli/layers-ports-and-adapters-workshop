<?php
use PHPUnit\Framework\TestCase;

class EmptyTestCaseTest extends TestCase
{
}
